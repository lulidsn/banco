
package Modelo;

public class Pro_Ques {
    
    private int num;
    private int num_prova;
    private int num_questoes;

    public Pro_Ques(int num, int num_prova, int num_questoes) {
        this.num = num;
        this.num_prova = num_prova;
        this.num_questoes = num_questoes;
    }

    public Pro_Ques() {
        this.num = 0;
        this.num_prova = 0;
        this.num_questoes = 0;
    }
    
    
}
